if (typeof define === 'function' && define.amd)
{
    define(function()
    {
        return org.cometd;
    });
}
